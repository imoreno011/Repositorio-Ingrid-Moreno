# S14_Mediaqueries-INGRID-MORENO

A Pen created on CodePen.

Original URL: [https://codepen.io/ingrid_md/pen/YPwVMEy](https://codepen.io/ingrid_md/pen/YPwVMEy).

