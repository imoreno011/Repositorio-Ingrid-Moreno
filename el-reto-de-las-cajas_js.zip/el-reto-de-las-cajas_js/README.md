# El reto de las cajas_JS

A Pen created on CodePen.

Original URL: [https://codepen.io/ingrid_md/pen/OPMOxNN](https://codepen.io/ingrid_md/pen/OPMOxNN).

